# FDE-Adoption-Growth — 执行清单


## 准备

- [ ] 使用数据
- [ ] 用户分层

## 执行

- [ ] 培训
- [ ] champion

## 验收

- [ ] WAU达标

## 复盘

- [ ] 续约材料


## FDE 阶段门禁

- [ ] PoC：场景卡双签、验收指标可量化、数据/权限前置条件满足
- [ ] Beta：周度 Demo 节奏建立、采纳看板或埋点就绪、失败样本入库
- [ ] 生产：RBAC-Audit + 评估回归 + 人审策略 + 运维 Runbook 过门禁
- [ ] 信创/私有化（如适用）：部署架构与 Gateway 审计项已确认

## 阻塞升级

- [ ] 阻塞超过 2 个工作日 → 升级 AIBP / 项目负责人
- [ ] 涉及安全合规/等保 → 同步 08-Security-Compliance/RBAC-Audit
- [ ] 范围变更 → 重走 SOW-Generator / 场景卡确认

